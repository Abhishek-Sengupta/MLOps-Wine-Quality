from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="Wine Quality Prediction- MLOps Project",
    author="Abhishek-Sengupta",
    packages=find_packages()
)


